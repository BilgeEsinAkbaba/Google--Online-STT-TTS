﻿using Google.Apis.Auth.OAuth2;
using Google.Cloud.Speech.V1;
using Grpc.Auth;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using NAudio.Wave;

namespace WebApplication4.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SpeechToTextController : ControllerBase
    {
        private readonly ILogger<SpeechToTextController> _logger;
        private readonly string _jsonFilePath;

        public SpeechToTextController(ILogger<SpeechToTextController> logger)
        {
            _logger = logger;
            // Google Speech-to-Text API'ye erişim için kullanılacak olan JSON kimlik bilgilerinin dosya yolu.
            _jsonFilePath = @"C:\Users\Bilge\OneDrive\Masaüstü\Proje1\WebApplication4\WebApplication4\Controllers\mineral-nebula-392006-7ac2744f4cfd.json";
        }

        [HttpPost]
        public async Task<IActionResult> UploadAudio(IFormFile formFile)
        {
            if (formFile != null)
            {
                // Dosyayı audio klasörüne kaydet
                var audioFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "audio");
                Directory.CreateDirectory(audioFolderPath);

                var audioFilePath = Path.Combine(audioFolderPath, formFile.FileName);
                using (var stream = new FileStream(audioFilePath, FileMode.Create))
                {
                    await formFile.CopyToAsync(stream);
                }

                string wavFilePath = audioFilePath;

                // Eğer dosya .wav uzantılı değilse dönüştür
                if (!Path.GetExtension(audioFilePath).Equals(".wav", StringComparison.OrdinalIgnoreCase))
                {
                    // Ses dosyasını WAV formatına dönüştür
                    wavFilePath = ConvertToWav(audioFilePath);

                    if (string.IsNullOrEmpty(wavFilePath))
                    {
                        return BadRequest("Failed to convert audio to WAV format.");
                    }
                }

                // WAV dosyasını metne dönüştür
                var result = ConvertAudioToText(wavFilePath);

                // Metni text klasörüne kaydet
                var textFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "text");
                Directory.CreateDirectory(textFolderPath);

                var fileName = Path.GetFileNameWithoutExtension(formFile.FileName);
                var textFilePath = Path.Combine(textFolderPath, $"{fileName}.txt");

                await System.IO.File.WriteAllTextAsync(textFilePath, result);

                return Ok(new { Result = result });
            }

            return BadRequest("No audio file provided.");
        }

        private string ConvertToWav(string audioFilePath)
        {
            try
            {
                using (var reader = new MediaFoundationReader(audioFilePath))
                {
                    var wavFilePath = Path.ChangeExtension(audioFilePath, ".wav");

                    if (reader.WaveFormat.Channels > 1)
                    {
                        // Convert stereo audio to mono
                        var monoReader = new StereoToMonoProvider16(reader);
                        var monoResampler = new MediaFoundationResampler(monoReader, new WaveFormat(reader.WaveFormat.SampleRate, 1));
                        WaveFileWriter.CreateWaveFile(wavFilePath, monoResampler);
                    }
                    else
                    {
                        // No need to convert, already mono
                        WaveFileWriter.CreateWaveFile(wavFilePath, reader);
                    }

                    return wavFilePath;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to convert audio to WAV format.");
                return null;
            }
        }

        private string ConvertAudioToText(string audioFilePath)
        {
            var googleCredential = GoogleCredential.FromFile(_jsonFilePath);
            var speechClient = new SpeechClientBuilder
            {
                ChannelCredentials = googleCredential.ToChannelCredentials()
            }.Build();

            var recognitionConfig = new RecognitionConfig
            {
                Encoding = RecognitionConfig.Types.AudioEncoding.Linear16,
                LanguageCode = "tr-TR"
            };

            var audio = RecognitionAudio.FromFile(audioFilePath);

            var response = speechClient.Recognize(recognitionConfig, audio);
            var result = response.Results.FirstOrDefault()?.Alternatives.FirstOrDefault()?.Transcript;

            return result;
        }
    }
}





