﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.TextToSpeech.V1;
using Grpc.Auth;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Linq;
using Microsoft.OpenApi.Any;
using System.Text.Json.Serialization;

namespace WebApplication4.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TextToSpeechController : ControllerBase
    {
        private readonly TextToSpeechClient _client;

        public TextToSpeechController()
        {
            // Google Text-to-Speech API'ye erişim için kullanılacak olan JSON kimlik bilgilerinin dosya yolu.
            var credentialsFilePath = @"C:\Users\Bilge\OneDrive\Masaüstü\Proje1\WebApplication4\WebApplication4\Controllers\mineral-nebula-392006-7ac2744f4cfd.json";
            var credentials = GoogleCredential.FromFile(credentialsFilePath).CreateScoped(TextToSpeechClient.DefaultScopes);
            _client = new TextToSpeechClientBuilder { ChannelCredentials = credentials.ToChannelCredentials() }.Build();
        }

        [HttpPost]
        public IActionResult ConvertTextToSpeech([FromQuery] TextToSpeechRequest request)
        {
            var input = new SynthesisInput
            {
                Text = request.Text
            };

            var selectedVoice = GetVoiceSelection(request.Voice);

            // Ses ayarları yapılandırması
            var audioConfig = new AudioConfig
            {
                AudioEncoding = AudioEncoding.Mp3
            };

            var response = _client.SynthesizeSpeech(input, selectedVoice, audioConfig);

            using (var memoryStream = new MemoryStream())
            {
                // Ses içeriğinin bellek akışına yazılması
                response.AudioContent.WriteTo(memoryStream);
                return File(memoryStream.ToArray(), "audio/mpeg", "output.mp3");
            }
        }

        private VoiceSelectionParams GetVoiceSelection(VoiceOption voiceOption)
        {
            switch (voiceOption)
            {
                case VoiceOption.FemaleStandardA:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Standard-A", SsmlGender = SsmlVoiceGender.Female };
                case VoiceOption.MaleStandardB:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Standard-B", SsmlGender = SsmlVoiceGender.Male };
                case VoiceOption.FemaleStandardC:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Standard-C", SsmlGender = SsmlVoiceGender.Female };
                case VoiceOption.FemaleStandardD:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Standard-D", SsmlGender = SsmlVoiceGender.Female };
                case VoiceOption.MaleStandardE:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Standard-E", SsmlGender = SsmlVoiceGender.Male };
                case VoiceOption.FemaleWavenetA:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Wavenet-A", SsmlGender = SsmlVoiceGender.Female };
                case VoiceOption.MaleWavenetB:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Wavenet-B", SsmlGender = SsmlVoiceGender.Male };
                case VoiceOption.FemaleWavenetC:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Wavenet-C", SsmlGender = SsmlVoiceGender.Female };
                case VoiceOption.FemaleWavenetD:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Wavenet-D", SsmlGender = SsmlVoiceGender.Female };
                case VoiceOption.MaleWavenetE:
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Wavenet-E", SsmlGender = SsmlVoiceGender.Male };
                default:
                    // If the provided voice option is not recognized, use the default male voice.
                    return new VoiceSelectionParams { LanguageCode = "tr-TR", Name = "tr-TR-Standard-A", SsmlGender = SsmlVoiceGender.Female };
            }
        }
    }

    public class TextToSpeechRequest
    {
        public string Text { get; set; }

        [JsonConverter(typeof(JsonStringEnumConverter))]
        public VoiceOption Voice { get; set; }
    }

    public enum VoiceOption
    {
        [Description("tr-TR-Standard-A")]
        FemaleStandardA,
        [Description("tr-TR-Standard-B")]
        MaleStandardB,
        [Description("tr-TR-Standard-C")]
        FemaleStandardC,
        [Description("tr-TR-Standard-D")]
        FemaleStandardD,
        [Description("tr-TR-Standard-E")]
        MaleStandardE,
        [Description("tr-TR-Wavenet-A")]
        FemaleWavenetA,
        [Description("tr-TR-Wavenet-B")]
        MaleWavenetB,
        [Description("tr-TR-Wavenet-C")]
        FemaleWavenetC,
        [Description("tr-TR-Wavenet-D")]
        FemaleWavenetD,
        [Description("tr-TR-Wavenet-E")]
        MaleWavenetE
    }

    //Açılır liste oluşturulması
    public class AddDropdownListParameter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
                operation.Parameters = new List<OpenApiParameter>();

            var enumDescriptions = Enum.GetValues(typeof(VoiceOption))
                .Cast<VoiceOption>()
                .Select(v => GetEnumDescription(v));

        }

        private string GetEnumDescription(VoiceOption value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());
            var attributes = fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (attributes.Length > 0)
                return ((DescriptionAttribute)attributes[0]).Description;
            return value.ToString();
        }
    }
}









